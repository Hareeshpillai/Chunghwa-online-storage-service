from flask import Flask
import flask


app = flask.Flask(__name__)
app.jinja_env.trim_blocks = True
app.jinja_env.lstrip_blocks = True

app = Flask(__name__)


@app.route('/')
def index():
    return flask.render_template("log.html.jinja2")

@app.route('/home')
def home():
    return flask.render_template("home.html.jinja2")

if __name__ == "__main__":
    app.run()