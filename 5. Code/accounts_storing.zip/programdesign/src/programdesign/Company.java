package programdesign;

public class Company {
	private int id;
	private String name;

	public Company(int id, String name, Document documents) {
		this.id = id;
		this.name = name;
	}

	public Company() {
		this.id = (int) (Math.random() * 100000);
		this.name = "no_name";
	}

	@Override
	public String toString() {
		return "Company\n				id=" + id + "\n				name=" + name + "\n";
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
	