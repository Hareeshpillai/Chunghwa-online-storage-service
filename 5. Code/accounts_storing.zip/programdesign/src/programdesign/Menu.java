package programdesign;

import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		String name_acc, password, name_folder, name_document;
		boolean flag = true;
		Accounts accs = new Accounts();
		Scanner input = new Scanner(System.in);

		System.out.println("Enter 1 to display all records");
		System.out.println("Enter 2 to create account");
		System.out.println("Enter 3 to display account record");
		System.out.println("Enter 4 to display folders");
		System.out.println("Enter 5 to change folder name");
		System.out.println("Enter 6 to add folder");
		System.out.println("Enter 7 to delete folder");
		System.out.println("Enter 8 to display 1 document");
		System.out.println("Enter 9 to change document name");
		System.out.println("Enter 10 to add document");
		System.out.println("Enter 11 to delete document");
		System.out.println("Enter 12 to move document");
		System.out.println("Enter 13 to add to important");
		System.out.println("Enter 14 to stop");

		while (flag) {
			String s = input.next();

			switch (s) {
			case "1":
				System.out.println(accs);
				break;

			case "2":
				System.out.print("Login: \nEnter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				Account acc = new Account(password, name_acc);
				accs.addAccount(acc);
				System.out.println(acc);
				break;

			case "3":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				int n = accs.size();
				for (int i = 0; i < n; i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						System.out.println(accs.get(i).toString());
					}
				}
				break;

			case "4":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				int n2 = accs.size();
				for (int i = 0; i < n2; i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						System.out.println(accs.get(i).getFolders());
					}
				}
				break;
			case "5":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter current folder name");
				name_folder = input.next();
				int n5 = accs.size();
				for (int i = 0; i < n5; i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						int nfolder = accs.get(i).getFolders().size();
						for (int j = 0; j < nfolder; j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								System.out.println("Enter new folder name");
								name_folder = input.next();
								accs.get(i).getFolders().get(j).setName(name_folder);
								System.out.println(accs.get(i));
							}
						}
					}
				}
				break;

			case "6":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				int n6 = accs.size();
				for (int i = 0; i < n6; i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						Folder new_folder = new Folder();
						new_folder.setName(name_folder);
						accs.get(i).addFolder(new_folder);
						System.out.println(accs.get(i));
					}
				}
				break;

			case "7":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				int n7 = accs.size();
				for (int i = 0; i < n7; i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						Folder new_folder = new Folder();
						new_folder.setName(name_folder);
						accs.get(i).addFolder(new_folder);
						System.out.println(accs.get(i));
					}
				}
				break;

			case "8":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				System.out.println("Enter document name");
				name_document = input.next();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								for (int l = 0; l < accs.get(i).getFolders().get(j).getDocs().size(); l++) {
									if (accs.get(i).getFolders().get(j).getDocs().get(l).getName()
											.equals(name_document)) {
										System.out.println(accs.get(i).getFolders().get(j).getDocs().get(l));
									}
								}
							}
						}
					}
				}
				break;

			case "9":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				System.out.println("Enter current document name");
				name_document = input.next();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								for (int l = 0; l < accs.get(i).getFolders().get(j).getDocs().size(); l++) {
									if (accs.get(i).getFolders().get(j).getDocs().get(l).getName()
											.equals(name_document)) {
										System.out.println("Enter new document name");
										name_document = input.next();
										accs.get(i).getFolders().get(j).getDocs().get(l).setName(name_document);
										;
										System.out.println(accs.get(i).getFolders().get(j).getDocs().get(l));
									}
								}
							}
						}
					}
				}
				break;

			case "10":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				System.out.println("Enter document name");
				name_document = input.next();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								Document doc = new Document();
								doc.setName(name_document);
								accs.get(i).getFolders().get(j).addDoc(doc);
								System.out.println(accs.get(i));
							}
						}
					}
				}
				break;

			case "11":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				System.out.println("Enter document name");
				name_document = input.next();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								for (int l = 0; l < accs.get(i).getFolders().get(j).getDocs().size(); l++) {
									if (accs.get(i).getFolders().get(j).getDocs().get(l).getName()
											.equals(name_document)) {
										accs.get(i).getFolders().get(j)
												.delDoc(accs.get(i).getFolders().get(j).getDocs().get(l));
										System.out.println(accs.get(i).getFolders().get(j));
									}
								}
							}
						}
					}
				}
				break;

			case "12":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter current folder name");
				name_folder = input.next();
				System.out.println("Enter target folder name");
				String name_folder_target = input.next();
				System.out.println("Enter name document");
				name_document = input.next();
				Folder from = new Folder();
				Folder to = new Folder();
				Document doc = new Document();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								from = accs.get(i).getFolders().get(j);
								for (int l = 0; l < accs.get(i).getFolders().get(j).getDocs().size(); l++) {
									if (accs.get(i).getFolders().get(j).getDocs().get(l).getName()
											.equals(name_document)) {
										doc = accs.get(i).getFolders().get(j).getDocs().get(l);
									}
								}
							}
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder_target)) {
								to = accs.get(i).getFolders().get(j);
							}
						}
						accs.get(i).moveDocument(from, to, doc);
						System.out.println(from);
						System.out.println(to);
					}
				}
				break;

			case "13":
				System.out.print("Enter account name");
				name_acc = input.next();
				System.out.println("Enter password");
				password = input.next();
				System.out.println("Enter folder name");
				name_folder = input.next();
				System.out.println("Enter document name");
				name_document = input.next();
				for (int i = 0; i < accs.size(); i++) {
					if (accs.get(i).getName().equals(name_acc) && accs.get(i).getPassword().equals(password)) {
						for (int j = 0; j < accs.get(i).getFolders().size(); j++) {
							if (accs.get(i).getFolders().get(j).getName().equals(name_folder)) {
								for (int l = 0; l < accs.get(i).getFolders().get(j).getDocs().size(); l++) {
									if (accs.get(i).getFolders().get(j).getDocs().get(l).getName()
											.equals(name_document)) {
										accs.get(i).addToImportant(accs.get(i).getFolders().get(j).getDocs().get(l));
										System.out.println(accs.get(i));
									}
								}
							}
						}
					}
				}
				break;

			case "14":
				flag = false;
				break;

			default:
				System.out.println("Error");
			}
		}
	}
}
