package programdesign;

import java.util.ArrayList;

public class Accounts {

	private ArrayList<Account> accounts;

	public Accounts() {
		this.accounts = new ArrayList<Account>();
	}

	public ArrayList<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(ArrayList<Account> accounts) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return "" + accounts ;
	}

	public void addAccount(Account acc) {
		this.accounts.add(acc);
	}

	public int size() {
		return accounts.size();
	}

	public Account get(int i) {
		return this.accounts.get(i);
	}
}