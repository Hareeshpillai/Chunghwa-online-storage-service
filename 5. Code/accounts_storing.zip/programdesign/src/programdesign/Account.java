package programdesign;

import java.util.ArrayList;

public class Account {

	private int id;
	private String password;
	private String name;
	private Folder important;
	private ArrayList<Folder> folders;
	private ArrayList<Company> companies;

	public Account(String password, String name) {
		this.id = (int) (Math.random() * 100000);
		this.password = password;
		this.name = name;
		this.folders = new ArrayList<Folder>();
		this.companies = new ArrayList<Company>();
		this.important = new Folder();

	}

	public int getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Folder> getFolders() {
		return folders;
	}

	public void setFolders(ArrayList<Folder> folders) {
		this.folders = folders;
	}

	public ArrayList<Company> getCompanies() {
		return companies;
	}

	public void setCompanies(ArrayList<Company> companies) {
		this.companies = companies;
	}

	public Folder getImportant() {
		return important;
	}

	public void addFolder(Folder fld) {
		this.folders.add(fld);
	}

	public void delFolder(Folder fld) {
		this.folders.remove(fld);
	}

	public void addCompany(Company cmp) {
		this.companies.add(cmp);
	}

	public void delCompany(Company cmp) {
		this.companies.remove(cmp);
	}

	public void moveDocument(Folder from, Folder to, Document doc) {
		from.delDoc(doc);
		to.addDoc(doc);
	}

	public void addToImportant(Document doc) {
		this.important.addDoc(doc);
	}

	@Override
	public String toString() {
		return "Account\n	id=" + id + "\n	password=" + password + "\n	name=" + 
	name + "\n	important=" + important
				+ "	folders=" + folders + "\n	companies=" + companies + "\n\n";
	}

}
