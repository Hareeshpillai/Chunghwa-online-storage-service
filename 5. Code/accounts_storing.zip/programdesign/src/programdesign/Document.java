package programdesign;

public class Document {

	private int id;
	private String name;
	private Company cmp;

	public Document(int id, String name, Company cmp) {
		this.id = id;
		this.name = name;
		this.cmp = cmp;
	}

	public Document() {
		this.id = (int) (Math.random() * 100000);
		this.name = "no_name";
		this.cmp = new Company();
	}

	@Override
	public String toString() {
		return "\n			id=" + id + 
			     "\n			nom=" + name + "\n			cmp=" + cmp + "\n";
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Company getCmp() {
		return cmp;
	}

	public void setCmp(Company cmp) {
		this.cmp = cmp;
	}
}
