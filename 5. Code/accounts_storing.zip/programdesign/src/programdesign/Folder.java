package programdesign;

import java.util.ArrayList;

public class Folder {

	private int id;
	private String name;
	private ArrayList<Document> docs;

	public Folder(int id, String name, ArrayList<Document> docs) {
		this.id = id;
		this.name = name;
		this.docs = docs;
	}

	public Folder() {
		this.id = (int) (Math.random() * 100000);
		this.name = "no_name";
		this.docs = new ArrayList<Document>();
	}

	@Override
	public String toString() {
		return "\n		id=" + id + "\n		name=" + 
	name + "\n		docs=" + docs + "]\n";
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Document> getDocs() {
		return docs;
	}

	public void setDocs(ArrayList<Document> docs) {
		this.docs = docs;
	}

	public void addDoc(Document doc) {
		this.docs.add(doc);
	}

	public void delDoc(Document doc) {
		this.docs.remove(doc);
	}

}
